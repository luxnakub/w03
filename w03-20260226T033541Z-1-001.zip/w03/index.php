<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>6714421030 - Workshop 03</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;600&display=swap');
        body { font-family: 'Sarabun', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 min-h-screen flex items-center justify-center py-10">

    <div class="w-full max-w-lg bg-white shadow-2xl rounded-2xl overflow-hidden">
        <div class="bg-indigo-700 p-6">
            <h1 class="text-2xl font-bold text-center text-white">ระบบคำนวณภาษีเงินได้</h1>
            <p class="text-center text-indigo-100 text-sm">รหัสนักศึกษา: 6714421030</p>
        </div>
        
        <form id="taxForm" class="p-8 space-y-5">
            <div class="space-y-4">
                <h2 class="text-lg font-semibold text-gray-800 border-b pb-2">1. ข้อมูลทั่วไป</h2>
                
                <div class="grid grid-cols-1 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">ชื่อ-นามสกุล</label>
                        <input type="text" id="user_name" required
                            class="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">อาชีพ</label>
                        <input type="text" id="user_job" 
                            class="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition">
                    </div>
                </div>

                <div>
                    <span class="block text-sm font-medium text-gray-700 mb-2">สถานภาพการสมรส</span>
                    <div class="flex flex-wrap gap-6">
                        <label class="inline-flex items-center cursor-pointer">
                            <input type="radio" name="marital_status" value="single" class="w-4 h-4 text-indigo-600 focus:ring-indigo-500" checked>
                            <span class="ml-2 text-gray-700">โสด</span>
                        </label>
                        <label class="inline-flex items-center cursor-pointer">
                            <input type="radio" name="marital_status" value="married" class="w-4 h-4 text-indigo-600 focus:ring-indigo-500">
                            <span class="ml-2 text-gray-700">สมรส</span>
                        </label>
                        <label class="inline-flex items-center cursor-pointer">
                            <input type="radio" name="marital_status" value="divorced" class="w-4 h-4 text-indigo-600 focus:ring-indigo-500">
                            <span class="ml-2 text-gray-700">หย่าร้าง</span>
                        </label>
                    </div>
                </div>
            </div>

            <div class="space-y-4 pt-4">
                <h2 class="text-lg font-semibold text-gray-800 border-b pb-2">2. รายได้และค่าลดหย่อน</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">รายได้ต่อปี (บาท)</label>
                        <input type="number" id="annual_income" step="0.01" required
                            class="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">ค่าลดหย่อนภาษี (บาท)</label>
                        <input type="number" id="tax_deduction" step="0.01" required
                            class="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition">
                    </div>
                </div>
            </div>

            <button type="submit" 
                class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl shadow-lg transform hover:-translate-y-0.5 transition duration-200">
                ประมวลผลข้อมูล
            </button>
        </form>

        <div id="resultDisplay" class="hidden p-8 bg-indigo-50 border-t border-indigo-100">
            <h3 class="text-lg font-bold text-indigo-900 mb-4 flex items-center">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                สรุปผลการคำนวณ
            </h3>
            <div class="space-y-3 text-gray-800">
                <div class="flex justify-between">
                    <span class="text-gray-600">ผู้เสียภาษี:</span>
                    <span id="res_name" class="font-semibold"></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-600">เงินได้สุทธิ:</span>
                    <span id="res_taxable" class="font-semibold text-blue-700"></span>
                </div>
                <div class="flex justify-between border-t pt-3 mt-3">
                    <span class="text-gray-900 font-bold">ภาษีที่ต้องชำระ:</span>
                    <span id="res_tax" class="font-bold text-red-600 text-xl"></span>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.getElementById("taxForm").addEventListener("submit", (e) => {
        e.preventDefault();

        const nameValue = document.getElementById("user_name").value;
        const totalIncome = parseFloat(document.getElementById("annual_income").value) || 0;
        const totalDeduction = parseFloat(document.getElementById("tax_deduction").value) || 0;

        let netTaxable = Math.max(0, totalIncome - totalDeduction);

        const taxBrackets = [
            { limit: 5000000, rate: 0.35 },
            { limit: 2000000, rate: 0.30 },
            { limit: 1000000, rate: 0.25 },
            { limit: 750000, rate: 0.20 },
            { limit: 500000, rate: 0.15 },
            { limit: 300000, rate: 0.10 },
            { limit: 150000, rate: 0.05 }
        ];

        const computeTax = (amount) => {
            let payable = 0;
            let remaining = amount;

            for (const bracket of taxBrackets) {
                if (remaining > bracket.limit) {
                    payable += (remaining - bracket.limit) * bracket.rate;
                    remaining = bracket.limit;
                }
            }
            return payable;
        };

        const taxDue = computeTax(netTaxable);
        const display = document.getElementById("resultDisplay");
        
        document.getElementById("res_name").textContent = nameValue;
        document.getElementById("res_taxable").textContent = netTaxable.toLocaleString() + " บาท";
        document.getElementById("res_tax").textContent = taxDue.toLocaleString() + " บาท";
        
        display.classList.remove("hidden");
    });
    </script>
</body>
</html>
